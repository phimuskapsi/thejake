const mariadb = require('mariadb');
const pool = mariadb.createPool({ 
  host: 'thejake.cg0hnf2mvri2.us-east-1.rds.amazonaws.com', 
  user: 'admin', 
  password: 'Niloc1723!' 
});


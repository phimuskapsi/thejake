<template>
  <div>    
    <v-container fluid>     
      <v-row>   
        
      </v-row>
    </v-container>
  </div>
</template>

<script>
 import NFLData from '../plugins/pffData.js';
  import * as moment from 'moment'
  
  export default {
    components: {  },
    data () {
      return {
      }
    },
    created() {

    },
    mounted() {

    },
    methods: {

    }
  }
</script>
<style scoped>

</style>
<template>
  <div>    
    <v-container fluid>     
      <v-row>
      </v-row>
    </v-container>
  </div>
</template>
<script>
  // import HistoricalJakes from './HistoricalJakes';
  import NFLData from '../plugins/pffData.js';
  import * as moment from 'moment'
  
  export default {
    components: {  },
    data () {
      return {

      }
    },
    methods: {

    }
  }
</script>
<style>
</style>

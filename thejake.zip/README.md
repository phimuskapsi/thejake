# thejake

## Project setup
```
npm install
```

### Start Local Server
```
node server/app
```

### Compiles and hot-reloads for development
```
npm run serve
```

